import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import PageNotFound from "./pages/PageNotFound ";
import "./index.css";
import RecoverAccount from "./pages/RecoverAccount";
import Signup from "./pages/Signup";
import Login from "./pages/Login";
import Map from "./pages/Map";
import { createRoot } from "react-dom/client";
import {
  createBrowserRouter,
  RouterProvider,
  Route,
  Link,
} from "react-router-dom";
import ResetPassword from "./pages/ResetPassword";
import Privacy from "./pages/Privacy";
const router = createBrowserRouter([
  {
    path: "/",
    element: <App />,
    children: [
      {
        path: "/signup",
        element: <Signup />,
      },
      {
        path: "/map",
        element: <Map />,
      },
      {
        path: "/login",
        element: <Login />,
      },
      {
        path: "/recover-account",
        element: <RecoverAccount />,
      },
      {
        path: "/reset-password",
        element: <ResetPassword />,
      },
    ],
  },
  { path: "/privacy", element: <Privacy /> },
  { path: "*", element: <PageNotFound/> },
]);

createRoot(document.getElementById("root")).render(
  <RouterProvider router={router} />
);
