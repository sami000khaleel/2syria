const Place = require('../models/placeModel'); // Import your Mongoose model
const mongoose=require('mongoose')
mongoose.connect('mongodb://127.0.0.1/2syria').then(async()=>{

    async function calculateAvgRating(placeId) {
        try {
        // Find the place by its ID
        const place = await Place.findById(placeId);
        
        if (!place) {
            console.log('Place not found');
            return;
        }
        
        // Calculate the total sum of ratings
        let totalSumOfRatings = 0;
        for (const review of place.reviews) {
            totalSumOfRatings += review.rating;
        }

        // Calculate the average rating
        const totalRatings = place.reviews.length;
        const avgRating = totalRatings > 0 ? totalSumOfRatings / totalRatings : 0;
        
        // Update the place's avgRating field
        place.avgRating = avgRating;
        await place.save();

        console.log('Average rating updated successfully:', avgRating);
    } catch (error) {
        console.error('Error calculating average rating:', error);
    }
}

// Example usage:
const places=await Place.find()
places.forEach(async(place) => {
    
   await calculateAvgRating(place.id);
});
})
