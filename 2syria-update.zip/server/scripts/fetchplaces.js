const axios = require("axios");
const fs = require("fs");
require("dotenv").config();
const filePath = "./places.json";
let places = [];
const key = "";
const url = "https://maps.googleapis.com/maps/api/place/textsearch/json";
const types = [
  "historical",
  "restaurant",
  "great view",
  "religios",
  "old ruin",
  "hotel",
];
const cities = [
  "Damascus",
  "Aleppo",
  "Homs",
  "Hamah",
  "Latakia",
  "Daraa",
  "Deir Al-Zur",
  "Al Raqqah",
  "Idleb",
  "Tartus",
  "Tartous",
  "Suwayda",
  "Palmyra",
  "Hasaka",
];
// cities.forEach(ciry=>{

// })
function appendDataToFile(places, filePath) {
  const jsonData = JSON.stringify(places, null, 2);
  fs.writeFile(filePath, jsonData, "utf8", (err) => {
    if (err) {
      console.error("Error appending to JSON file:", err);
    } else {
      console.log("Data appended to file successfully");
    }
  });
}

async function getPlaces(city, url, key, placesType) {
  try {
    let { data } = await axios.get(url, {
      params: {
        query: `${placesType} places in ${city} syria`,
        key,
      },
    });
    let { results } = data;
    results.forEach((place) => {
      place.type = placesType;
      place.city = city;
    });
    places.push(...results);
    appendDataToFile(places, filePath);
  } catch (err) {
    console.log(err);
    throw err;
  }
}

async function fetchPlaces() {
  for (const placesType of types) {
    for (const city of cities) {
      await getPlaces(city, url, key, placesType);
      console.log(`${placesType} places in ${city} syria`);
    }
  }
}

async function go() {
  await fetchPlaces();
  appendDataToFile(places, "./places.json");
}

go();
