const fs = require('fs');

// Read the JSON file
fs.readFile('./places.json', 'utf8', (err, data) => {
  if (err) {
    console.error('Error reading file:', err);
  } else {
    try {
      const places = JSON.parse(data); // Parse the JSON data into an array of places
      const uniquePlaces = Array.from(new Map(places.map(place => [place.place_id, place])).values()); // Filter out duplicate places based on their IDs

      // Write the unique places to a new JSON file
      fs.writeFile('./unique-places.json', JSON.stringify(uniquePlaces, null, 2), 'utf8', (err) => {
        if (err) {
          console.error('Error writing file:', err);
        } else {
          console.log('Unique places have been saved to unique-places.json');
        }
      });
    } catch (error) {
      console.error('Error parsing JSON:', error);
    }
  }
});
