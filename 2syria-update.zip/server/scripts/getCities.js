const mongoose = require("mongoose");
const Place = require("../models/placeModel");
async function go() {
  let cities = [];
  await mongoose.connect("mongodb://127.0.0.1/2syria");
  let places = await Place.find();
  let counter = 0;
  for (let place of places) {
    if (!place.city) counter++;
    if (
      place.city === "Alep" ||
      place.city === "قبب بنية" ||
      place.city === "urum al-kubra" ||
      place.city === "Al Nerab"
    )
      place.city = "Aleppo";
    else if (
      place.city === "Al Nozha" ||
      place.city === "Al Mukharram Alfuqaney" ||
      place.city === "Marmarita" ||
      place.city === "Al Mazra'a" ||
      place.city === "Hims" ||
      place.city === "As Sukhnah" ||
      place.city === "Shinshar" ||
      place.city === "Almishtaya"
    )
      place.city = "Homs";
    else if (
      place.city === "Bishalama" ||
      place.city === "Kesab" ||
      place.city === "Lattaquié" ||
      place.city === "Taytūzalaq" ||
      place.city === "اللاذقية" ||
      place.city === "عين جندل"
    )
      place.city = "Latakia";
    else if (
      place.city === "Ghmam" ||
      place.city === "Jillen" ||
      place.city === "Dael" ||
      place.city === "Al Jeezah" ||
      place.city === "Tal Shihab" ||
      place.city === "Qarfa" ||
      place.city === "Ibtta" ||
      place.city === "Busra"
    )
      place.city = "Daraa";
    else if (
      place.city === "Kudajran" ||
      place.city === "A'zaz" ||
      place.city === "Deir Semaan" ||
      place.city === "الباب" ||
      place.city === "Btgramo" ||
      place.city === "Mjdlya" ||
      place.city === "حلب" ||
      place.city === "Bza'a" ||
      place.city === "Manbij" ||
      place.city === "القرعة كبير" ||
      place.city === "Al-Rai" ||
      place.city === "Jubb Hasan Agha" ||
      place.city === "Al Bab"
    )
      place.city = "Aleppo";
    else if (place.city === "Ar Raqqah") place.city = "Al Raqqah";
    else if (
      place.city == "Alsurman" ||
      place.city === "Shnan" ||
      place.city === "Urum al-Joz" ||
      place.city === "Idlib" ||
      place.city === "Qmenas" ||
      place.city === "Sarmadā" ||
      place.city === "السودة" ||
      place.city === "Hesh" ||
      place.city === "Ma'arat Ann Nu'man" ||
      place.city === "Aldana" ||
      place.city === "Al-Bara" ||
      place.city === "Kafar Roma" ||
      place.city === "Bsakla" ||
      place.city === "Aanjar"
    )
      place.city = "Idleb";
    else if (
      place.city === "Zahrat Almadaen" ||
      place.city === "Ma`arat al-Nu`man" ||
      place.city === "Safita" ||
      place.city === "Hawash" ||
      place.city === "Hama" ||
      place.city === "Salamiyah" ||
      place.city === "صماغ" ||
      place.city === "Taldara" ||
      place.city === "Muhradah"
    )
      place.city = "Hamah";
    else if (
      place.city === "Qanawat" ||
      place.city === "Shahba" ||
      place.city === "Era" ||
      place.city === "As Suwayda" ||
      place.city === "Suwayda" ||
      place.city === "Soueïda" ||
      place.city === "shahba"
    )
      place.city = "Suwayda";
    else if (place.city === "Palmyre") place.city = "Palmyra";
    else if (
      place.city === "Qamishli" ||
      place.city == "القامشلي" ||
      place.city === "Kameshli" ||
      place.city === "Hasaka"
    )
      place.city = "Hasaka";
    else if (
      place.city === "Al Rabwa" ||
      place.city === "Yafour" ||
      place.city === "Badda" ||
      place.city === "Sayyida Zeinab" ||
      place.city === "Set Zaynab" ||
      place.city === "Dżubb al-Kadżli" ||
      place.city === "تريكية صغير" ||
      place.city === "Yabrud" ||
      place.city === "Qal'at Salah ad Din" ||
      place.city === "Talfita" ||
      place.city === "Sednayah" ||
      place.city === "Al-Jobeh" ||
      place.city === "Yabroud" ||
      place.city === "Moltaqa Al-Nahreen" ||
      place.city === "فدرة" ||
      place.city === "Damas" ||
      place.city === "Duma" ||
      place.city === "Bloudan" ||
      place.city === "Al Qastal" ||
      place.city === "An Nabk" ||
      place.city === "Al Nabk" ||
      place.city === "Al-Atnah" ||
      place.city === "Al-Hamidiah"
    )
      place.city = "Damascus";
    else if (
      place.city === "Mashta al Helou" ||
      place.city === "الدويلية" ||
      place.city === "طرطوس" ||
      place.city === "Maaloula" ||
      place.city === "Al Sehel" ||
      place.city === "Tartus" ||
      place.city === "Al Futasiyah" ||
      place.city === "Hosain Al Bahir" ||
      place.city === "بيت ناعسة"
    )
      place.city = "Tartous";
    else if (
      place.city === "Dayr az Zawr" ||
      place.city === "Deir ez-Zur" ||
      place.city === "Al Tabiyyah Jazeerah" ||
      place.city === "ديرالزور"
    )
      place.city = "Deir Al-Zur";
    await place.save();
  }

  for (let place of places) console.log(place.city);
  places.forEach((place) => {
    if (!cities.includes(place.city) && place.city) cities.push(place.city);
  });
  console.log(cities);
  process.exit();
}
go();
