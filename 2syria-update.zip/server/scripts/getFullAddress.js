const axios = require('axios');
require('dotenv').config()
const Place=require('../models/placeModel')
const mongoose=require('mongoose')
const apiKey = '';
let cities=new Set()
  // Make a request to the Google Maps Geocoding API using Axios
  mongoose.connect('mongodb://127.0.0.1/2syria').then(async()=>{
  let places= await Place.find({type:'hotel'})
  for(let i=0;i<places.length;i++){
    // if(places[i].city)
      // continue
    const {lat,lng}=places[i].location  
  const response= await  axios.get(`https://maps.googleapis.com/maps/api/geocode/json?latlng=${lat},${lng}&key=${apiKey}`)
      // Parse the response to extract the city name
      const addressComponents = response.data.results[0].address_components;
      console.log(addressComponents)
      let city;
      for (let component of addressComponents) {
        if (component.types.includes('locality')) {
          city = component.long_name;
          places[i].city=city
          // await places[i].save()
          cities.add(city)
          console.log(places[i].name)
          break;
        }
      }
      console.log(cities,i)
      console.log('City:', city);
  }
})
