const axios = require('axios');
const Place = require('../models/placeModel'); // Assuming your model file is in the models directory
const fs = require('fs');
const path = require('path');
const mongoose=require('mongoose')

// Function to fetch and save images
async function fetchAndSaveImages() {
  try {
      await mongoose.connect('mongodb://127.0.0.1/2syria')
      const places = await Place.find({ type: { $ne: 'hotel' } });
      console.log(places.length)
      for (let i=0;i<places.length;i++) {
          console.log('place '+i)
          console.log(places[i].place_id)
          for (let j=0;j<places[i].photos.length;j++) {
              console.log('image '+j)

              const placeId = places[i].place_id;
              const photoPath = path.join(__dirname,'..','data','images', placeId, `${places[i].photos[j].photo_reference}.jpg`);
              
              // Check if the image file already exists
              if (!fs.existsSync(photoPath)) {
                  const url = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${places[i].photos[j].photo_reference}&key=`;

                  const response = await axios.get(url, { responseType: 'arraybuffer' }).catch(err=>console.log(err.message));

                  if (response && response.data) {
                      const photoData = response.data;
                      const placeDir = path.join(__dirname,'..','data','images', placeId); // Create a directory named after place_id
                      if (!fs.existsSync(placeDir)) {
                          fs.mkdirSync(placeDir);
                      }

                      fs.writeFileSync(photoPath, photoData, 'binary');
                  }
              } else {
                  console.log(`Image ${j}.jpg for place ${i} already exists.`);
              }
          }
          await places[i].save(); // Save the updated place document
      }
  } catch (error) {
      console.error('Error fetching and saving images:', error.message);
  }
}

fetchAndSaveImages();
