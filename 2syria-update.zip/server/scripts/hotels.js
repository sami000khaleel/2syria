const axios = require('axios');
const fs = require('fs');
const Place = require('../models/placeModel');
const path = require('path');
const mongoose = require('mongoose');
mongoose.connect('mongodb://127.0.0.1/2syria').then(()=>{

  // Function to fetch hotels in Syria
  async function fetchHotelsInSyria() {
  const apiKey =''
  const syriaBounds = '32.0,35.5|37.5,42.0'; // Replace with the bounds of Syria
  const type = 'lodging'; // Type for hotels

  try {
    const response = await axios.get(`https://maps.googleapis.com/maps/api/place/nearbysearch/json?location=34.802075,38.996815&radius=50000&type=${type}&key=${apiKey}`);
    const hotels = response.data.results;

    for (let hotel of hotels) {
      await fetchAndSaveHotelPhotos(hotel.place_id, apiKey);
      await saveHotelToDatabase(hotel);
    }
  } catch (error) {
    console.error('Error fetching hotels:', error);
  }
}

// Function to fetch and save hotel photos
async function fetchAndSaveHotelPhotos(placeId, apiKey) {
  try {
    const response = await axios.get(`https://maps.googleapis.com/maps/api/place/details/json?place_id=${placeId}&fields=photos&key=${apiKey}`);
    const photos = response.data.result.photos;
    
    if (photos) {
      for (let photo of photos) {
        const photoReference = photo.photo_reference;
        const photoUrl = `https://maps.googleapis.com/maps/api/place/photo?maxwidth=400&photoreference=${photoReference}&key=${apiKey}`;
        const folderPath = path.join(__dirname, `../data/images/${placeId}`);

        if (!fs.existsSync(folderPath)) {
          fs.mkdirSync(folderPath, { recursive: true });
        }
        
        const photoPath = path.join(folderPath, `${photoReference}.jpg`);
        const writer = fs.createWriteStream(photoPath);
        
        const photoResponse = await axios({
          url: photoUrl,
          method: 'GET',
          responseType: 'stream',
        });

        photoResponse.data.pipe(writer);
        
        console.log(`Saved photo for place_id ${placeId}: ${photoReference}`);
      }
    }
  } catch (error) {
    console.error(`Error fetching photos for place_id ${placeId}:`, error);
  }
}

// Function to save hotel to the database
async function saveHotelToDatabase(hotel) {
  try {
    const newPlace = new Place({
      place_id: hotel.place_id,
      city: hotel.city,
      name: hotel.name,
      photos: hotel.photos,
      photosUrl: hotel.photosUrl,
      location: hotel.geometry.location,
      description: hotel.description,
      type: 'hotel'
    });
    
    await newPlace.save();
    console.log(`Saved hotel ${hotel.name} to the database`);
  } catch (error) {
    console.error(`Error saving hotel ${hotel.name} to the database:`, error);
  }
}

// Call the function to fetch hotels in Syria
fetchHotelsInSyria();

})
