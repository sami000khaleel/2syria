const Place=require('../models/placeModel.js')
const mongoose=require('mongoose')
const fs=require('fs')
mongoose.connect('mongodb://127.0.0.1/2syria').then(()=>{

    let places=JSON.parse(fs.readFileSync('C:/Users/sami/Desktop/projects/2syria/server/scripts/places.json'))
  
    console.log(places[0].place_id)
    places=places.map(place=>({
        name:place.name,
        location:place.geometry.location,
    place_id:place.place_id,
    reference:place.reference,
    type:place.type,
    photos:place.photos,
    description:'',
    address:place.formatted_address,
    avgRating:0

}))

Place.insertMany(places).then(res=>console.log('done')).catch(err=>console.log(err))
}).catch(err=>console.log(err))
