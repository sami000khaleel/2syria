const mongoose = require('mongoose');
const User = require('../models/userModel'); // Assuming you have a User model defined

async function registerUsers() {
    const users = [];

    const userData = [
        { userName: 'john_doe', email: 'john@example.com', password: 'password123' },
        { userName: 'jane_doe', email: 'jane@example.com', password: 'password456' },
        { userName: 'bob_smith', email: 'bob@example.com', password: 'password789' },
        { userName: 'alice_smith', email: 'alice@example.com', password: 'passwordabc' },
        { userName: 'charlie_brown', email: 'charlie@example.com', password: 'passworddef' }
    ];

    try {
        await mongoose.connect('mongodb://127.0.0.1/2syria', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });

        for (let i = 0; i < userData.length; i++) {
            const { userName, email, password } = userData[i];
            
            const user = new User({ userName, email, password });
            await user.save();
            console.log(`User saved successfully: ${userName}, ${email}`);
            users.push(user);
        }
    } catch (error) {
        console.error('Error registering users:', error);
    } finally {
        mongoose.disconnect();
    }

    return users;
}

registerUsers()
    .then(users => {
        console.log('All users registered:', users);
    })
    .catch(error => {
        console.error('Error registering users:', error);
    });
