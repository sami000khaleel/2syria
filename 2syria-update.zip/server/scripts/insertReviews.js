const User=require('../models/userModel')
const mongoose=require('mongoose')
const Place=require('../models/placeModel')
function generateReviewSentence() {
    const subjects = ['The place', 'This location', 'The establishment', 'The venue', 'This spot'];
    const adjectives = ['was amazing', 'was fantastic', 'was great', 'was wonderful', 'was excellent'];
    const experiences = ['and provided an unforgettable experience.', 'and I thoroughly enjoyed my time there.', 'and exceeded my expectations.', 'and left me impressed.', 'and I would highly recommend it.'];

    const randomSubject = subjects[Math.floor(Math.random() * subjects.length)];
    const randomAdjective = adjectives[Math.floor(Math.random() * adjectives.length)];
    const randomExperience = experiences[Math.floor(Math.random() * experiences.length)];

    return `${randomSubject} ${randomAdjective} ${randomExperience}`;
}
async function generateReviewsForUsers() {
    try {
        await mongoose.connect('mongodb://127.0.0.1/2syria', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });

        // Find all users
        const users = await User.find();

        // Find all places
        const places = await Place.find();

        // Iterate over each user
        for (const user of users) {
            // Generate a random number of reviews for the user
            const numberOfReviews = Math.floor(Math.random() * places.length) + 1;

            // Shuffle places array
            const shuffledPlaces = places.sort(() => 0.5 - Math.random());

            // Get selected places for review
            const selectedPlaces = shuffledPlaces.slice(0, numberOfReviews);

            // Generate reviews for selected places
            const reviews = selectedPlaces.map(place => {
                return {
                    userId: user._id,
                    rating: Math.floor(Math.random() * 5) + 1, // Random rating between 1 and 5
                    review: generateReviewSentence(), // Generate meaningful review sentences
                    place_id: place._id // Reference to the place
                };
            });

            // Save reviews within the places
            for (const review of reviews) {
                const place = places.find(place => place._id.equals(review.place_id));
                if (place) {
                    place.reviews.push({
                        userId: review.userId,
                        rating: review.rating,
                        review: review.review
                    });
                    await place.save();
                }
            }

            console.log(`Reviews added for user ${user.userName}`);
        }

        console.log('Reviews added for all users.');
    } catch (error) {
        console.error('Error generating reviews:', error);
    } finally {
        console.log('a')
        mongoose.disconnect();
    }
}
generateReviewsForUsers()
