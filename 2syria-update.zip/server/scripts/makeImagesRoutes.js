const mongoose=require('mongoose')
const fs=require('fs')
const path=require('path')
const Place=require('../models/placeModel')
mongoose.connect('mongodb://127.0.0.1/2syria').then(async()=>{
const places=await Place.find()
let objects=[
]
for (let place of places){
   const placePath=path.join(__dirname,'..','data','images',place.place_id)
   
   let obj={placeName:place.name,type:place.type,city:place.city,place_id:place.place_id,urls:[]}
   for (let photo of place.photos){
         const imagePath=path.join(placePath,photo.photo_reference)
         obj.urls.push(imagePath)
      }
      objects.push(obj)
   
}
fs.writeFileSync('../data/place.json',JSON.stringify(objects))
process.exit()
})
