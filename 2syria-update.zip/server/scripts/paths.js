const path=require('path')
const fs = require('fs');
let objects=JSON.parse(fs.readFileSync('../data/place.json'))
function convertToOpenCVPath(windowsPath) {
    // Replace backslashes with forward slashes
    const forwardSlashesPath = windowsPath.replace(/\\/g, '/');
    // Replace spaces with %20
    const cvReadablePath = encodeURI(forwardSlashesPath);
    return cvReadablePath;
}

for (let i = 0; i < objects.length; i++) 
    for (let j = 0; j < objects[i].urls.length; j++) 
{
        objects[i].urls[j] = convertToOpenCVPath(objects[i].urls[j]);
        
        }
        fs.writeFileSync('../data/place.json',JSON.stringify(objects))
        console.log('done')
