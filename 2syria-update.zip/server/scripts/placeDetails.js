require('dotenv').config()
const Place=require('../models/placeModel')
const mongoose = require('mongoose');
const axios=require('axios')
const fs=require('fs')
// const places=JSON.parse(fs.readFileSync('C:/Users/sami/Desktop/projects/2syria/server/data/places.json'))
let details=[]
let counter=0
async function go(){
  await mongoose.connect('mongodb://127.0.0.1/2syria')
  let places=await Place.find({type:'hotels'})
  
  console.log(places.length) 
  for(let i=0;i<places.length;i++)
  {
    const {data}=await axios.get(`https://maps.googleapis.com/maps/api/place/details/json?fields=photo&place_id=${places[0].place_id}&key=''`)
    counter++
    places[i].photos=data.result.photos
    await places[i].save()
    console.log(i)
  }

}
go()
