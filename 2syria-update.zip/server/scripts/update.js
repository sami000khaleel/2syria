const XLSX = require('xlsx');
const fs = require('fs');
const path=require('path')
// Read the JSON file
const jsonPath=path.join(__dirname,'2syria.places.json')
console.log(jsonPath)
const rawData = fs.readFileSync(jsonPath, 'utf8');
const data = JSON.parse(rawData);

// Create a new workbook
const workbook = XLSX.utils.book_new();

// Prepare the data for the worksheet
const worksheetData = [
  // Header row
  ['id', 'name', 'city', 'type', 'suitableForBadWeather']
];

// Add data rows
data.forEach(item => {
  worksheetData.push([
    item._id.$oid,
    item.name,
    item.city || item.location?.city || '',
    item.type,
    ''  // Empty column for suitableForBadWeather
  ]);
});

// Create a worksheet
const worksheet = XLSX.utils.aoa_to_sheet(worksheetData);

// Add the worksheet to the workbook
XLSX.utils.book_append_sheet(workbook, worksheet, 'Syria Places');

// Write the workbook to a file
XLSX.writeFile(workbook, 'syria_places.xlsx');

console.log('Excel file created successfully: syria_places.xlsx');
