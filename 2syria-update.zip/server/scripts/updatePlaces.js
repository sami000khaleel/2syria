const mongoose = require('mongoose');
const User = require('../models/userModel');
const Place = require('../models/placeModel');

async function deleteReviewsByUsers() {
    try {
        await mongoose.connect('mongodb://127.0.0.1:27017/2syria', {
            useNewUrlParser: true,
            useUnifiedTopology: true
        });

        // Find users named "Sami" and "Samxi"
        const usersToDelete = await User.find({ userName: { $in: ['Sami', 'Samxi'] } });

        // Iterate over users to delete their reviews
        for (const user of usersToDelete) {
            // Find places reviewed by the user
            const placesReviewed = await Place.find({ 'reviews.userId': user._id });

            // Iterate over places to delete user's reviews
            for (const place of placesReviewed) {
                place.reviews = place.reviews.filter(review => !review.userId.equals(user._id));
                await place.save();
            }

            // Clear user's placesReviewed array
            user.placesReviewed = [];
            await user.save();
            console.log(`Reviews deleted for user ${user.userName}`);
        }

        console.log('Reviews deleted for specified users.');
    } catch (error) {
        console.error('Error deleting reviews:', error);
    } finally {
        mongoose.disconnect();
    }
}

deleteReviewsByUsers();
